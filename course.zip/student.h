/**
 * @file student.h
 * @author Tony Lin
 * @brief a student library for managing students
 * @version 0.1
 * @date 2022-04-03
 * 
 * @copyright Copyright (c) 2022
 * 
 */


/**
 * @brief Student type that stores a student with members: first_name, last_name, id, *grades and num_grades.
 * 
 */

typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

// function definitions
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
