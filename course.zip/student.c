/**
 * @file student.c
 * @author Tony Lin
 * @brief a student library for managing students
 * @version 0.1
 * @date 2022-04-03
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief a function that adds a grade to a student
 * 
 * @param student a struct that contain necessary student information
 * @param grade a double value that represents the grade being given to the student
 * 
 * @return void 
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // initialize the first grade if one doesn't exist
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    // increases size and adds the grade
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief this function calculates and returns the students grade average
 * 
 * @param student a struct that contain necessary student information
 * 
 * @return double the students average
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  // loops through and calculates a students grade average
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief this function prints all of the students important information including: name, id, grades, and average.
 * 
 * @param student a struct that contain necessary student information
 * 
 * @return void
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // loops through and prints all of the student's grades
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief this function creates a randomly generated student
 * 
 * @param grades an integer value representing the students grades
 * @return Student* the pointer to a student
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  
  // generates the space of a student on heap
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // loops through 10 times and randomly generate a new user id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // loops through and randomly adds grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}