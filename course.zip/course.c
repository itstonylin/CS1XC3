/**
 * @file course.c
 * @author Tony Lin 
 * @brief a course library for managing courses
 * @version 0.1
 * @date 2022-04-03
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief this function enrolls a student in a course
 * 
 * @param course a struct that contains necessary course information
 * @param student a struct that contain necessary student information
 * 
 * @return void
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    // initialize the first student in the course
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    // adds more users to the course
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief this function prints all of the course information
 * 
 * @param course a struct that contains necessary course information
 * 
 * @return void 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // loops through and prints all the students
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief this function returns the student with the highest average in the inputted course.
 * 
 * @param course a struct that contains necessary course information
 * @return Student* the pointer to the student with the highest average in the course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  // loops through and finds highest average student
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief this function returns the number of students in a course that is passing
 * 
 * @param course a struct that contains necessary course information
 * @param total_passing a pointer whose value is later set to the number of students passing the course
 * @return Student* a pointer to an array of students who are passing the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // loops through and finds number of students passing
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // makes an array with the number of students passing
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // adds the students that are passing into the array
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}